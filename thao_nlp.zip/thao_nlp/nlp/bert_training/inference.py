"""
Inference engine for trained PhoBERT models
"""

import json
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


class InferenceEngine:
    """Handles model inference for predictions"""
    
    def __init__(self, model_directory='./phobert-finetuned'):
        self.model_directory = model_directory
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load model and tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(model_directory)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_directory)
        self.model.to(self.device)
        self.model.eval()
        
        # Load label mappings
        with open(f'{model_directory}/label_map.json', 'r', encoding='utf-8') as f:
            label_info = json.load(f)
        self.id2label = {int(k): v for k, v in label_info['id2label'].items()}
    
    def predict_text(self, input_text):
        """Predict sentiment for input text"""
        tokenized = self.tokenizer(
            input_text,
            add_special_tokens=True,
            max_length=256,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        tokenized = {k: v.to(self.device) for k, v in tokenized.items()}
        
        with torch.no_grad():
            model_output = self.model(**tokenized)
            probabilities = torch.nn.functional.softmax(model_output.logits, dim=-1)
            predicted_idx = torch.argmax(probabilities, dim=-1).item()
            confidence_score = probabilities[0][predicted_idx].item()
        
        return {
            'label': self.id2label[predicted_idx],
            'confidence': confidence_score,
            'all_scores': {self.id2label[i]: probabilities[0][i].item() 
                          for i in range(len(self.id2label))}
        }


# ============================================================================
# TEST INFERENCE
# ============================================================================
if __name__ == "__main__":
    print("Testing Inference Engine...")
    
    inference_engine = InferenceEngine(model_directory='./phobert-finetuned')
    
    test_samples = [
        "40:00 ối dồi ôi",
        "Video rất hay và bổ ích!",
        "Tệ quá, không xem được"
    ]
    
    for text in test_samples:
        prediction = inference_engine.predict_text(text)
        print(f"\nInput: {text}")
        print(f"Prediction: {prediction['label']} (confidence: {prediction['confidence']:.4f})")
        print(f"All scores: {prediction['all_scores']}")
