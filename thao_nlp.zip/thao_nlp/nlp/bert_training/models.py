"""
Core models, dataset, and utilities for PhoBERT fine-tuning
"""

import json
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TrainerCallback


# ============================================================================
# CONFIGURATION
# ============================================================================
class Config:
    """Centralized configuration parameters"""
    MODEL_NAME = 'vinai/phobert-base'
    MAX_SEQ_LENGTH = 256
    DEFAULT_BATCH_SIZE = 16
    DEFAULT_LEARNING_RATE = 2e-5
    DEFAULT_EPOCHS = 10
    VALIDATION_SPLIT = 0.2
    WARMUP_STEPS = 100
    WEIGHT_DECAY = 0.01
    RANDOM_SEED = 42


# ============================================================================
# DATASET
# ============================================================================
class TextClassificationDataset(Dataset):
    """Custom PyTorch Dataset for text classification with PhoBERT tokenization"""
    
    def __init__(self, text_samples, label_indices, tokenizer_instance, seq_length=256):
        self.text_samples = text_samples
        self.label_indices = label_indices
        self.tokenizer_instance = tokenizer_instance
        self.seq_length = seq_length
    
    def __len__(self):
        return len(self.text_samples)
    
    def __getitem__(self, index):
        text_content = str(self.text_samples[index])
        label_value = self.label_indices[index]
        
        tokenized_output = self.tokenizer_instance(
            text_content,
            add_special_tokens=True,
            max_length=self.seq_length,
            padding='max_length',
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': tokenized_output['input_ids'].flatten(),
            'attention_mask': tokenized_output['attention_mask'].flatten(),
            'labels': torch.tensor(label_value, dtype=torch.long)
        }


# ============================================================================
# DATA LOADER
# ============================================================================
class DatasetLoader:
    """Handles loading and preprocessing from Parquet or JSON files"""
    
    @staticmethod
    def parse_data_file(filepath):
        """Load and parse data from Parquet or JSON"""
        text_collection = []
        label_collection = []
        
        # Kiểm tra định dạng file
        if filepath.endswith('.parquet'):
            print(f"📖 Đọc file Parquet: {filepath}")
            df = pd.read_parquet(filepath)
            
            # Kiểm tra cột cần thiết
            if 'content' not in df.columns or 'label' not in df.columns:
                raise ValueError("Parquet file phải có cột 'content' và 'label'")
            
            parsed_records = df.to_dict('records')
            
        else:
            # Đọc JSON (giữ nguyên logic cũ)
            print(f"📖 Đọc file JSON: {filepath}")
            with open(filepath, 'r', encoding='utf-8') as file_handle:
                raw_content = file_handle.read().strip()
                file_handle.seek(0)
                
                try:
                    if raw_content.startswith('{'):
                        json_data = json.loads(raw_content)
                        if 'comments' not in json_data:
                            raise ValueError("Missing 'comments' key in JSON object")
                        parsed_records = json_data['comments']
                    elif raw_content.startswith('['):
                        parsed_records = json.loads(raw_content)
                    else:
                        parsed_records = [json.loads(line) for line in file_handle if line.strip()]
                except json.JSONDecodeError as error:
                    print(f"JSON parsing error: {error}")
                    raise
        
        # Create label mappings
        distinct_labels = list(set([record['label'] for record in parsed_records if record['label']]))
        label_to_id = {label: idx for idx, label in enumerate(distinct_labels)}
        id_to_label = {idx: label for label, idx in label_to_id.items()}
        
        # Extract texts and encoded labels
        for record in parsed_records:
            if record['label']:  # Chỉ lấy record có label
                text_collection.append(record['content'])
                label_collection.append(label_to_id[record['label']])
        
        print(f"✅ Đã nạp {len(text_collection)} mẫu dữ liệu")
        return text_collection, label_collection, label_to_id, id_to_label


# ============================================================================
# MODEL MANAGER
# ============================================================================
class ModelManager:
    """Manages model download, loading, and saving operations"""
    
    @staticmethod
    def fetch_pretrained_model(model_identifier='vinai/phobert-base', destination_path='./phobert-pretrained'):
        """Download and cache pretrained PhoBERT model"""
        print(f"Fetching model: {model_identifier}...")
        os.makedirs(destination_path, exist_ok=True)
        
        tokenizer = AutoTokenizer.from_pretrained(model_identifier)
        model = AutoModelForSequenceClassification.from_pretrained(
            model_identifier,
            num_labels=3
        )
        
        tokenizer.save_pretrained(destination_path)
        model.save_pretrained(destination_path)
        
        print(f"Model cached at: {destination_path}")
        return destination_path
    
    @staticmethod
    def load_cached_model(cache_dir, num_classes, label_mappings):
        """Load model from local cache"""
        tokenizer = AutoTokenizer.from_pretrained(cache_dir)
        model = AutoModelForSequenceClassification.from_pretrained(
            cache_dir,
            num_labels=num_classes,
            id2label=label_mappings['id2label'],
            label2id=label_mappings['label2id'],
            ignore_mismatched_sizes=True
        )
        return tokenizer, model


# ============================================================================
# METRICS
# ============================================================================
class MetricsComputer:
    """Computes various classification metrics"""
    
    @staticmethod
    def calculate_metrics(evaluation_predictions):
        """Calculate comprehensive classification metrics"""
        pred_logits, true_labels = evaluation_predictions
        predicted_classes = np.argmax(pred_logits, axis=1)
        
        metrics_dict = {
            'accuracy': accuracy_score(true_labels, predicted_classes),
            'f1_macro': f1_score(true_labels, predicted_classes, average='macro', zero_division=0),
            'f1_weighted': f1_score(true_labels, predicted_classes, average='weighted', zero_division=0),
            'precision': precision_score(true_labels, predicted_classes, average='weighted', zero_division=0),
            'recall': recall_score(true_labels, predicted_classes, average='weighted', zero_division=0)
        }
        
        return metrics_dict


# ============================================================================
# TRAINING CALLBACK
# ============================================================================
class TrainingMetricsTracker(TrainerCallback):
    """Custom callback to track training and validation metrics during training"""
    
    def __init__(self):
        self.training_loss_history = []
        self.validation_loss_history = []
        self.epoch_tracker = []
    
    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs:
            if 'loss' in logs:
                print(f"Step {state.global_step}: Loss = {logs['loss']:.4f}")
            if 'eval_loss' in logs:
                self.epoch_tracker.append(state.epoch)
                self.validation_loss_history.append(logs['eval_loss'])
    
    def on_epoch_end(self, args, state, control, **kwargs):
        if state.log_history:
            recent_train_losses = [log['loss'] for log in state.log_history if 'loss' in log]
            if recent_train_losses:
                self.training_loss_history.append(np.mean(recent_train_losses[-10:]))
