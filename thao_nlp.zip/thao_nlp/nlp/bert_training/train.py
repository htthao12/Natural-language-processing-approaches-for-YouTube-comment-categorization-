
import os
import json
import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score,
    classification_report, confusion_matrix
)
from transformers import TrainingArguments, Trainer

from .models import (
    Config, TextClassificationDataset, DatasetLoader, 
    ModelManager, MetricsComputer, TrainingMetricsTracker
)


class VisualizationEngine:
    """Handles all visualization tasks"""
    
    @staticmethod
    def generate_training_curves(metrics_tracker, save_directory):
        """Generate and save training/validation loss curves"""
        plt.figure(figsize=(12, 5))
        
        plt.subplot(1, 2, 1)
        if metrics_tracker.training_loss_history:
            epochs_range = range(1, len(metrics_tracker.training_loss_history) + 1)
            plt.plot(epochs_range, metrics_tracker.training_loss_history, 
                    'b-', label='Train Loss', linewidth=2)
        if metrics_tracker.validation_loss_history:
            plt.plot(metrics_tracker.epoch_tracker, metrics_tracker.validation_loss_history, 
                    'r-', label='Val Loss', linewidth=2)
        
        plt.xlabel('Epoch', fontsize=11, fontweight='bold')
        plt.ylabel('Loss', fontsize=11, fontweight='bold')
        plt.title('Training and Validation Loss', fontsize=13, fontweight='bold')
        plt.legend(fontsize=10)
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        output_path = f'{save_directory}/training_history.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Training curves saved: {output_path}")
    
    @staticmethod
    def generate_confusion_matrix(true_labels, predicted_labels, class_names, save_directory):
        """Generate and save confusion matrix visualization"""
        cm = confusion_matrix(true_labels, predicted_labels)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=class_names, yticklabels=class_names,
                   cbar_kws={'label': 'Count'})
        plt.title('Confusion Matrix', fontsize=14, fontweight='bold')
        plt.ylabel('True Label', fontsize=11, fontweight='bold')
        plt.xlabel('Predicted Label', fontsize=11, fontweight='bold')
        plt.tight_layout()
        
        output_path = f'{save_directory}/confusion_matrix.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"Confusion matrix saved: {output_path}")


# ============================================================================
# MODEL EVALUATOR
# ============================================================================
class ModelEvaluator:
    """Comprehensive model evaluation"""
    
    @staticmethod
    def perform_evaluation(trainer_instance, validation_data, label_mappings, output_path):
        """Run full evaluation and generate reports"""
        prediction_results = trainer_instance.predict(validation_data)
        predicted_classes = np.argmax(prediction_results.predictions, axis=1)
        true_classes = prediction_results.label_ids
        
        # Calculate metrics
        eval_metrics = {
            'accuracy': accuracy_score(true_classes, predicted_classes),
            'f1_macro': f1_score(true_classes, predicted_classes, average='macro', zero_division=0),
            'f1_weighted': f1_score(true_classes, predicted_classes, average='weighted', zero_division=0),
            'precision': precision_score(true_classes, predicted_classes, average='weighted', zero_division=0),
            'recall': recall_score(true_classes, predicted_classes, average='weighted', zero_division=0)
        }
        
        # Print results
        print("\n" + "="*60)
        print("FINAL EVALUATION METRICS")
        print("="*60)
        for metric_name, metric_value in eval_metrics.items():
            print(f"{metric_name.upper():15s}: {metric_value:.4f}")
        print("="*60)
        
        # Classification report
        class_names = [label_mappings[i] for i in sorted(label_mappings.keys())]
        print("\nDetailed Classification Report:")
        print(classification_report(true_classes, predicted_classes, 
                                   target_names=class_names, zero_division=0))
        
        # Generate confusion matrix
        VisualizationEngine.generate_confusion_matrix(
            true_classes, predicted_classes, class_names, output_path
        )
        
        return eval_metrics


class PhoBERTFineTuner:
    """Main class orchestrating the fine-tuning pipeline"""
    
    def __init__(self, config=Config()):
        self.config = config
        self.computing_device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Computation device: {self.computing_device}")
    
    def execute_training(self, data_file='youtube.json', model_cache_dir='./phobert-pretrained',
                        output_path='./phobert-finetuned', epochs=10, batch_size=16, 
                        learning_rate=2e-5, max_length=256):
        """Execute complete training pipeline"""
        
        # Load and prepare data
        print("Loading dataset...")
        texts, labels, label2id, id2label = DatasetLoader.parse_data_file(data_file)
        print(f"Dataset size: {len(texts)} samples")
        print(f"Label mapping: {label2id}")
        
        # Split data
        train_x, val_x, train_y, val_y = train_test_split(
            texts, labels, test_size=self.config.VALIDATION_SPLIT, 
            random_state=self.config.RANDOM_SEED, stratify=labels
        )
        print(f"Training: {len(train_x)} | Validation: {len(val_x)}")
        
        # Load model
        print(f"\nLoading model from: {model_cache_dir}")
        tokenizer, model = ModelManager.load_cached_model(
            model_cache_dir, len(label2id), {'label2id': label2id, 'id2label': id2label}
        )
        
        # Prepare datasets
        train_dataset = TextClassificationDataset(train_x, train_y, tokenizer, max_length)
        val_dataset = TextClassificationDataset(val_x, val_y, tokenizer, max_length)
        
        # Setup training configuration
        os.makedirs(output_path, exist_ok=True)
        
        training_config = TrainingArguments(
            output_dir=output_path,
            num_train_epochs=epochs,
            per_device_train_batch_size=batch_size,
            per_device_eval_batch_size=batch_size,
            learning_rate=learning_rate,
            warmup_steps=self.config.WARMUP_STEPS,
            weight_decay=self.config.WEIGHT_DECAY,
            logging_dir=f'{output_path}/logs',
            logging_steps=10,
            evaluation_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=True,
            metric_for_best_model="f1_weighted",
            greater_is_better=True,
            save_total_limit=3,
            fp16=torch.cuda.is_available(),
            report_to="none",
            disable_tqdm=False
        )
        
        # Initialize tracker and trainer
        metrics_tracker = TrainingMetricsTracker()
        
        trainer = Trainer(
            model=model,
            args=training_config,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            compute_metrics=MetricsComputer.calculate_metrics,
            callbacks=[metrics_tracker]
        )
        
        # Train model
        print("\n" + "="*50)
        print("TRAINING INITIATED")
        print("="*50)
        
        trainer.train()
        
        # Generate visualizations
        VisualizationEngine.generate_training_curves(metrics_tracker, output_path)
        
        # Evaluate model
        final_results = ModelEvaluator.perform_evaluation(
            trainer, val_dataset, id2label, output_path
        )
        
        # Save artifacts
        print(f"\nPersisting model to: {output_path}")
        trainer.save_model(output_path)
        tokenizer.save_pretrained(output_path)
        
        with open(f'{output_path}/label_map.json', 'w', encoding='utf-8') as f:
            json.dump({'label2id': label2id, 'id2label': id2label}, f, 
                     ensure_ascii=False, indent=2)
        
        with open(f'{output_path}/final_metrics.json', 'w', encoding='utf-8') as f:
            json.dump(final_results, f, ensure_ascii=False, indent=2)
        
        print("\nTraining pipeline completed successfully!")
        
        return trainer, final_results


# ============================================================================
# MAIN EXECUTION
# ============================================================================
if __name__ == "__main__":
    MODEL_CACHE = './phobert-pretrained'
    
    # Ensure model is available
    if not os.path.exists(MODEL_CACHE):
        print("Cached model not found. Downloading...")
        ModelManager.fetch_pretrained_model(
            model_identifier='vinai/phobert-base', 
            destination_path=MODEL_CACHE
        )
    else:
        print(f"Using cached model from: {MODEL_CACHE}")
    
    # Initialize and execute training
    fine_tuner = PhoBERTFineTuner()
    trained_model, metrics = fine_tuner.execute_training(
        data_file='youtube.json',
        model_cache_dir=MODEL_CACHE,
        output_path='./phobert-finetuned',
        epochs=1000,
        batch_size=64,
        learning_rate=2e-5
    )
